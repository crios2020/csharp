﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase01
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             *  Curso:          Introducción a la programacion C# .net
             *  Duracción:      15 hs.
             *  Días:           Sábado 10:00 a 13:00 hs.
             *  Profe:          Carlos Ríos     carlos.rios@educacionit.com
             * 
             *  Software:       Visual Studio Community 20XX
             *  alternativos:   Monodevelop         SharpDevelop
             *  
             *  Materiales:     alumni.educacionit.com
             *                  user:   email
             *                  pass:   dni
             *  github:         https://github.com/crios2020/csharp
             *  
             *  IDE: Integrated Development Enviroment (Enterno de desarrollo integrado)
            */

            // comentarios de una sola linea.
            /*
             * Bloque
             * de
             * Comentarios
             */

            Console.WriteLine("Hola Mundo!");       //Imprime en consola

            // ; Terminador de sentencias.
            // Lenguaje es Case Sensitive.

            /*
                        Consola de sistema!     

                    Hola Mundo!
                    Curso de .net
                    1234
                    EducacionIT
                    Presione una tecla para continuar.

             */

            Console.WriteLine("Curso de .net");
            Console.Write("1");
            Console.Write("2");
            Console.Write("3");
            Console.WriteLine("4");
            Console.WriteLine("EducacionIT");

            //Variables
            /*
             * C# .net es un lenguaje tipado fuerte!
             * 
             * las variables se almacenan en Memoria RAM
             * 
             * RAM:             Velocidad       Volatil         Caro
             * 
             * DISCO Duro:      Lento           Persistente     Economico
             */

            // Tipo de datos entero
            int a;      //declarar una variable.
            a = 2;      //asignar de valor a una variable.

            int b = 4;  //declarar y asignar valos a una variable.

            int c = a + b;

            int d = 5, e = 16, f = 32, g = 81;      //declaración y asignación multiples.

            // int a = 8;   // error variable ya declarada
            //Una variable solo puede declararse una vez, pero puede tener infinitas asignaciones de valores.
            a = 8;
            a = 21;
            a = 7;
            a = 5;

            Console.WriteLine(a);
            Console.WriteLine("Variable a: " + a);
            Console.WriteLine("a+b=" + a + b);              // a+b=54
            Console.WriteLine("a+b=" + (a + b));            // a+b=9         

            // tipo de datos string
            string p = "perro";
            string q = "ladra";

            Console.WriteLine(p + q);               //perroladra
            Console.WriteLine(p + " " + q);         //perro ladra
            Console.WriteLine(p + " que " + q);     //perro que ladra

            // tipo de datos char   unicode 2 bytes
            char ch = (char)65;    //'A';
            Console.WriteLine(ch);
            ch = 't';
            Console.WriteLine(ch);

            // tipo de datos float  32 bits
            float fl = 9.25f;
            Console.WriteLine(fl);

            // tipo de datos double 64 bits
            double dl = 9.25;
            Console.WriteLine(dl);

            fl = 10;
            dl = 10;
            Console.WriteLine(fl / 3);
            Console.WriteLine(dl / 3);


            fl = 100;
            dl = 100;
            Console.WriteLine(fl / 3);
            Console.WriteLine(dl / 3);

            // Tipo de datos boolean        1 bit
            bool bo = true;             // 1
            bo = false;                 // 0
            Console.WriteLine(bo);

            // Indetificadores (variables - constantes - atributos - métodos - o clases)

            // - Una Variable se escribe en minuscula.
            // - Una constante se escribe en mayuscula.
            // - Letras A-Z o a-z alfabeto ingles.
            // - Se pueden colocar números, pero no puede iniciar con un número.    int nro1; //correcto            int 1nro; //error
            // - Utilizamos camelCase           int velocidadMaxima;

            /*
             * Tabla de verdad!!
             * Pendiente!!!!
             * 
             */

            //freno de consola.
            Console.WriteLine("Presione una tecla para continuar.");
            Console.ReadKey();                      //Espera el ingreso de una tecla
        }
    }
}
