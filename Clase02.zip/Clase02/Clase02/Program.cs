﻿using System;

namespace Clase02
{
	class Program
	{
		public static void Main(string[] args)
		{
			
			//Clase 02
			
			//Operadores
			
			//Operador de asignación	=
			int nro1=5;
			int nro2=8;
			
			Console.WriteLine(nro1+" "+nro2);
			
			nro1=nro2;
			// <--
			
			Console.WriteLine(nro1+" "+nro2);
			
			//Operador de comparación ==
			Console.WriteLine(nro1==nro2);
			Console.WriteLine(nro1==10);
			
			//Operadores incrementales
			//Sumar 1 a la variable ++
			nro1 ++;				//nro1=nro1+1;
			Console.WriteLine(nro1);
			
			//Restar 1 a la variable --
			nro1 --;				//nro1=nro1-1;
			Console.WriteLine(nro1);
			
			//Sumar 5 a la vriables +=
			nro1+=5;				//nro1=nro1+5;
			Console.WriteLine(nro1);
			
			//Restar 5 a la variable -=
			nro1-=5;				//nro1=nro1-5;
			Console.WriteLine(nro1);
			
			//Multiplicar la variable *=
			nro1*=5;				//nro1=nro1*5;
			Console.WriteLine(nro1);
			
			//Dividir la variable /=
			nro1/=5;				//nro1=nro1/5;
			Console.WriteLine(nro1);
			
			/*
			 * 	Operadores Logicos
			 * 
			 * 	==				Equals (Comparación)
			 * 	!=				Not Equals
			 * 	< <= > >=
			 * 	!				Not
			 *  &&				AND
			 * 	||				OR
			 */

			Console.WriteLine(nro1==10);		//false
			Console.WriteLine(nro1==(6+2));		//true
			Console.WriteLine(nro1!=10);		//true
			Console.WriteLine(nro1!=8);			//false
			Console.WriteLine(nro1<8);			//false
			Console.WriteLine(nro1<=8);			//true
			
			//Tablas de Verdad
			/*
			 * 		X			Y				OR				AND
			 * 		F			F				F				F
			 * 		F			V				V				F
			 * 		V			F				V				F
			 * 		V			V				V				V
			 */
			
			bool log1=true;
			bool log2=false;
			
			Console.WriteLine(log1 || log2);		//true
			Console.WriteLine(log1 && log2);		//false
			
			//Operadores Binarios | OR Binarios		 & And Binario
			Console.WriteLine(log1 | log2);			//true
			Console.WriteLine(log1 & log2);			//false
			
			Console.WriteLine(log1 || (23+23-2+6)==1);		//true
			Console.WriteLine(log1 |  (23+23-2+6)==1);		//true
			
			Console.WriteLine(log2 && (23+23-2+6)==1);		//false
			Console.WriteLine(log2 &  (23+23-2+6)==1);		//false
			
			Console.WriteLine(!log1 || nro1==(3+5));		//true
			
			Console.WriteLine(log1);						//true
			Console.WriteLine(!log1);						//false
			Console.WriteLine(!!log1);						//true
			Console.WriteLine(!!!log1);						//false
			Console.WriteLine(!!!!log1);					//true
			
			//Precedencia y procedencia de operador unario ++ --
			Console.WriteLine(nro1);			//8
			Console.WriteLine(nro1++);			//9
			Console.WriteLine(nro1);			//9
			Console.WriteLine(++nro1);			//10
			
			//Constantes
			//Almacena un valor, de un tipo de datos, y solo puede tener una asignación en el momento de la declaración.
			//Nunca cambia de valor.
			const float PI=3.14f;
			Console.WriteLine(PI);
			//PI++;		//Error no se puede cambiar el valor de una constante.
			
			//Estructura condicional if
			if(log1)
			{	// llaves en modo recomendado para C# .net
				Console.WriteLine("Verdad 1");
			}
			nro1=10;
			if(nro1==10){		// llaves en modo recomendado para Java
				Console.WriteLine("Verdad 2");
				Console.WriteLine("Verdad 2");
				Console.WriteLine("Verdad 2");
				//código esta indentado
			}
			
			//llaves en modo abreviado
			if(nro1==10) Console.WriteLine("Verdad 3");
			
			//Estructura condicional if - else
			if(nro1!=10)
			{	// llaves en modo recomendado para C# .net
				Console.WriteLine("Verdad 4");
			}
			else
			{
				Console.WriteLine("Falso 4");
			}
			
			if(nro1==10) { // llaves en modo recomendado para Java
				Console.WriteLine("Verdad 5");
			}else{
				Console.WriteLine("Falso 5");
			}
			
			//llaves en modo abreviado
			if(nro1==10)	Console.WriteLine("Verdad 6");
			else			Console.WriteLine("Falso 6");
			
			
			//Incio de Sessión LOGIN
			//para iniciar el programa debe ingresar el usuario username="admin" y el pass="123";
			Console.WriteLine("****************************************************************");
			Console.WriteLine("* 			Sistema de Gestión 								  *");
			Console.WriteLine("****************************************************************");
			Console.WriteLine();
			Console.Write("Ingrese su Username: ");
			string user=Console.ReadLine();
			Console.WriteLine();
			Console.Write("Ingrese su Password: ");
			string pass=Console.ReadLine();
			Console.WriteLine();
			
			//Console.WriteLine(user+" "+pass);
			/*
			if(user=="admin")
			{
				if(pass=="123")	//if anidado
				{
					Console.WriteLine("Bienvenidos al sistema!");
				}
				else
				{
					Console.WriteLine("Password Incorrecto!");
				}
			} 
			else
			{
				Console.WriteLine("Usuario Incorrecto!");
			}
			*/
			
			if(user=="admin" && pass=="123") 	Console.WriteLine("Bienvenidos al sistema!");
			if(user=="admin" && pass!="123") 	Console.WriteLine("Password Incorrecto!");
			if(user!="admin")					Console.WriteLine("Usuario Incorrecto!");	
			
			//Console.WriteLine("2"+"2");				// 22
			//Console.WriteLine(2+2);					// 4
			
			
			
			
			// Temas Pendiente Estructura switch
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}