﻿using System;

namespace Clase03
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Clase 03

            //Estructura switch case
            int var1 = 12;
            double var2 = 3.001;


            switch ((int)var2)
            {
                case 1: Console.WriteLine("Valor 1"); break;
                case 2: Console.WriteLine("Valor 2"); break;
                case 3: Console.WriteLine("Valor 3"); break;
                case 4: case 5: case 6: case 7: case 8: case 9:
                    Console.WriteLine("Valor entre 4 y 9"); break;
                case 10: Console.WriteLine("Valor 10"); break;
                default: Console.WriteLine("Valor no esperado!"); break;
            }


            //Sensor: "rain", "snowing", "sunny", "warm", "cold"
            string sensor = "sunny";
            switch (sensor)
            {
                case "rain": Console.WriteLine("Salir con paraguas!"); break;
                case "sunny": case "warm": Console.WriteLine("Llevar agua!"); break;
                case "snowing": case "cold": Console.WriteLine("Llevar abrigo"); break;
                default: Console.WriteLine("Buen viaje!"); break;




            } //end switch


            //Estructura While
            int x = 1;
            Console.WriteLine("-- Inicio Estructura While --");
            while (x <= 10)
            {
                Console.WriteLine(x);           // 1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 - 9 - 10
                x++;
            }//end while
            Console.WriteLine("-- Fin Estructura While --");
            Console.WriteLine(x);               // 11

            //llaves en modo recomendado por Java
            x = 1;
            while (x <= 10) {
                Console.WriteLine(x);
                x++;
            }

            //Modo de llaves abreviado
            x = 1;
            while(x<=10) Console.WriteLine(x++);

            //loop infinito
            //x = 1;
            //while (true)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}

            //loop Infinito
            //x = 1;
            //while(x<=10 || true)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}

            //loop Infinito
            //x = 1;
            //while (x <= 10 || x>=1)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}

            //loop Infinito
            //x = 1;
            //while (x <= 10 || true)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}

            //loop Infinito
            //x = 1;
            //while (x <= 10)
            //{
            //    Console.WriteLine(x--);
            //    x++;
            //}

            //loop Infinito
            //x = 1;
            //while (x <= 10) ;
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}

            //Ejemplo While
            x = 12;
            Console.WriteLine("-- Inicio Estructura While --");
            while (x <= 10)
            {
                Console.WriteLine(x);           // 1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 - 9 - 10
                x++;
            }//end while
            Console.WriteLine("-- Fin Estructura While --");
            Console.WriteLine(x);

            //Estructura do while
            x = 12;
            Console.WriteLine("-- Inicio Estructura Do While --");
            do
            {
                Console.WriteLine(x);
                x++;
            } while (x <= 10);
            Console.WriteLine("-- Fin Estructura Do While --");
            Console.WriteLine(x);

            //Ejemplo While
            x = 1;
            Console.WriteLine("-- Inicio Estructura While --");
            while (x <= 10)
            {
                Console.WriteLine(x);           // 1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 - 9 - 10
                x++;
            }//end while
            Console.WriteLine(x);
            //Estructura for
            Console.WriteLine("-- Inicio Estructura For --");
            for(int a=40; a>=20; a-=2)
            {
                Console.WriteLine(a);
            }
            Console.WriteLine("-- Fin Estructura For --");
            //Console.WriteLine(a);     //Error la variable a esta destruida (fuera de scoped).

            //Modo de uso de llaves recomendado por java
            for(int a = 1; a <= 10; a++) {
                Console.WriteLine(a);
            }

            //Modo de llaves Abreviado
            for (int a = 1; a <= 10; a++) Console.WriteLine(a);

            //Recorrido for usando variables de control global
            Console.WriteLine("***********************************************");
            for(x=1; x<=10; x++)
            {
                Console.WriteLine(x);
            }
            Console.WriteLine("***********************************************");
            Console.WriteLine(x);       //11
            Console.WriteLine("***********************************************");
            for (x++; x <= 20; x++) Console.WriteLine(x);
            Console.WriteLine("***********************************************");
            for (; x <= 30; x++) Console.WriteLine(x);

            //For anidado
            int cont = 1;
            for(int a = 1; a <= 10; a++)
            {
                for(int b = 1; b <= 10; b++)
                {
                    for(int c = 1; c <= 10; c++)
                    {
                        Console.WriteLine(a+" "+b+" "+c+" "+(cont++));
                    }
                }
            }


        }//end main
    }//end MainClase
}//end Namespace Clase03
