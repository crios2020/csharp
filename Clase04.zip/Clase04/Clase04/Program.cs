﻿using System;

namespace Clase04
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Clase 04

            int x = 0;
            for (; x <= 10; x++)
            {
                Console.WriteLine(x);
            }

            x = 0;
            for (; x <= 10;)
            {
                Console.WriteLine(x++);
                //x++;
            }

            // recorrido con multiples variables de control
            for (int r = 1, s = 1; r <= 5 && s <= 10; r++, s++)
            {
                Console.WriteLine(r + " " + s);
            }

            for (int r = 1, s = 1; r <= 5 || s <= 10; r++, s++)
            {
                Console.WriteLine(r + " " + s);
            }

            //For anidado
            int cont = 1;
            for (int a = 1; a <= 10; a++)
            {
                for (int b = 1; b <= 10; b++)
                {
                    for (int c = 1; c <= 10; c++)
                    {
                        Console.WriteLine(a + " " + b + " " + c + " " + (cont++));
                    }
                }
            }

            //Horas de un reloj
            /*
            for(int hora=0; hora<24; hora++)
            {
                for(int minuto=0; minuto<60; minuto++)
                {
                    for(int segundo=0; segundo<60; segundo++)
                    {
                        Console.WriteLine(hora + ":" + minuto + ":" + segundo);
                    }
                }
            }
            */

            //loop infinito
            //for (;;);

            //for (; true;) ;

            //for(int a=1;a<=10 || a>=1; a++)
            //{
            //    Console.WriteLine(a);
            //}

            x = 2;
            x = 3;
            //for(int a = x; x <= 10; a++)
            //{
            //    Console.WriteLine(a);
            //}

            //for(int a=x; a<=10; x++)
            //{
            //    Console.WriteLine(x);
            //}


            // Vectores - Arrays

            // Declaración de vectores.
            int[] numeros = new int[4];
            string[] nombres = new string[4];
            // Los dos vectores tienen Grado (longitud) 4

            // cargar los vectores con valores
            // La primer posición de un vector tiene indice 0 
            // y la ultima posición tiene indice Grado-1 
            numeros[0] = 1;
            nombres[0] = "Juan";
            numeros[1] = 2;
            nombres[1] = "Maria";
            numeros[2] = 3;
            nombres[2] = "Jose";
            numeros[3] = 4;
            nombres[3] = "Marta";

            //Error fuera de Rango
            //numeros[4] = 5;
            //nombres[4] = "Karina";

            /*
             *      numeros         nombres         indice
             *          1           Juan            0
             *          2           Maria           1
             *          3           Jose            2
             *          4           Marta           3  
             *          5           Javier          4
             *          6           Irma            5            
             */             
             
            Console.WriteLine(numeros[2] + " " + nombres[2]);

            Console.WriteLine("**********************************");
            //Recorrido de un vector
            for(int a = 0; a < 4; a++)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }

            //Redimensionar un vector
            Array.Resize(ref numeros, 6);
            Array.Resize(ref nombres, 6);

            numeros[4] = 5;
            nombres[4] = "Javier";
            numeros[5] = 6;
            nombres[5] = "Irma";

            Console.WriteLine("**********************************");
            //Recorrido usando método length
            Console.WriteLine("Longitud de Vector Numeros: " + numeros.Length);
            for (int a = 0; a < numeros.Length; a++)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }
            Console.WriteLine("**********************************");
            //Recorrido en sentido reverso
            for(int a=numeros.Length-1; a>=0; a--)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }

            //Recorrido usando Estructura While
            Console.WriteLine("**********************************");
            x = 0;
            while (x < numeros.Length)
            {
                Console.WriteLine(numeros[x] + " " + nombres[x]);
                x++;
            }

            Console.WriteLine("**********************************");
            //Declaración abreviada
            int[] vector = {23,12,34,10,12,11,16,18,20,12,25,40,12,17 };
            string[] semana = {"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo" };

            Console.WriteLine("Longitud vector: " + vector.Length);
            Console.WriteLine("Longitud Semana: " + semana.Length);

            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            for (int a = 0; a < semana.Length; a++) Console.WriteLine(semana[a]);


            Console.WriteLine("**********************************");
            //Totalizar un vector númerico.
            //Promediar un vector númerico.

            int sumador = 0;
            for (int a = 0; a < vector.Length; a++) sumador += vector[a];
            Console.WriteLine("Total: " + sumador);
            Console.WriteLine("Promedio: " + ((double)sumador / vector.Length));

            //Buscar Valor Mínimo
            //Buscar Valor Máximo
            int min=vector[0];
            int max=vector[0];
            //int[] vector = {23,12,34,10,12,11,16,18,20,12,25,40,12,17 };
            for(int a = 1; a < vector.Length; a++)
            {
                if (min > vector[a]) min = vector[a];
                if (max < vector[a]) max = vector[a];
            }
            Console.WriteLine("Valor Mínimo: " + min);
            Console.WriteLine("Valor Máximo: " + max);


            // Operador Resto %
            Console.WriteLine(17 % 3);          // 2


            Console.WriteLine( 15 % 2);          //  1
            Console.WriteLine( 14 % 2);          //  0
            Console.WriteLine(  0 % 2);          //  0
            Console.WriteLine(-14 % 2);          //  0
            Console.WriteLine(-15 % 2);          // -1


            //Contar cantidad Números Pares
            //Contar cantidad Números ImPares
            //Contar cantidad Número 12.

            int contPares = 0, contImPares = 0, cont12 = 0;
            for(int a = 0; a < vector.Length; a++)
            {
                if (vector[a] % 2 == 0) contPares++;
                else contImPares++;
                if (vector[a] == 12) cont12++;
            }
            Console.WriteLine("Cantidad Números Pares: " + contPares);
            Console.WriteLine("Cantidad Números Impares: " + contImPares);
            Console.WriteLine("Cantidad de Número 12: " + cont12);

            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            //Ordenar un vector
            Array.Sort(vector);

            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            //Revertir un vector
            Array.Reverse(vector);

            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            Console.WriteLine("===============================================");
            for (int a = 0; a < semana.Length; a++) Console.WriteLine(semana[a]);

            Array.Sort(semana);

            Console.WriteLine("===============================================");
            for (int a = 0; a < semana.Length; a++) Console.WriteLine(semana[a]);

            Array.Reverse(semana);

            Console.WriteLine("===============================================");
            for (int a = 0; a < semana.Length; a++) Console.WriteLine(semana[a]);

        }
    }
}
