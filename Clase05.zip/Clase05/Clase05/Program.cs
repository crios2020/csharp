﻿using System;

namespace Clase05
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Clase 05
            Console.WriteLine("Clase 05");

            int[] pares = { 2, 4, 6, 8, 10 };
            int[] impares = new int[pares.Length];

            /*
             *      pares           impares     pares2
             *          2            ___         ___
             *          4            ___         ___
             *          6            ___         ___
             *          8            ___         ___
             *         10            ___         ___
             */             

            //copiar de vector pares a impares

            for(int a = 0; a < pares.Length; a++)
            {
                impares[a] = pares[a]-1;
            }

            for(int a = 0; a < pares.Length; a++)
            {
                Console.WriteLine(pares[a] + "\t" + impares[a]);
            }

            //copiar vectores usando la funcion.
            int[] pares2 = new int[pares.Length];
            Array.Copy(pares, pares2, pares.Length);

            for (int a = 0; a < pares.Length; a++)
            {
                Console.WriteLine(pares[a] + "\t" + pares2[a]);
            }

            // Sistema de Login
            string[] usuarios = { "Juan", "Jose", "Maria", "Ana" };
            string[] claves = { "123", "111", "abc", "321" };

            /*
            Console.WriteLine("***********************************************");
            Console.WriteLine("*            Gestión de Usuarios              *");
            Console.WriteLine("***********************************************");
            Console.WriteLine();
            Console.Write("Ingrese su nombre de usuario: ");
            string usuario = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese su clave: ");
            string clave = Console.ReadLine();
            Console.WriteLine();

            bool existe = false;
            int donde = 0;

            for(int a = 0; a < usuarios.Length; a++)
            {
                if (usuario == usuarios[a])
                {
                    existe = true;
                    donde = a;
                }
            }
            // Console.WriteLine(existe + " " + donde);
            if (existe && clave == claves[donde])   Console.WriteLine("Bienvenido "+usuario);
            if (existe && clave != claves[donde])   Console.WriteLine("Clave Incorrecta!");
            if (!existe)                            Console.WriteLine("Usuario Inexistente!");
            */

            printRojo ("Hola a todos!");
            printVerde("Hola a todos!");
            printAzul ("Hola a todos!");

            printRojo(sumar(26, 38)+"");


        }//end Main


        //Funciones
        public static int sumar(int nro1, int nro2)
        {
            return nro1 + nro2;
        }

        public static void printRojo(string texto)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(texto);
            Console.ResetColor();
        }

        public static void printVerde(string texto)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texto);
            Console.ResetColor();
        }

        public static void printAzul(string texto)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(texto);
            Console.ResetColor();
        }

    }//end class MainClass
} //end namespace
