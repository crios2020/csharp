﻿/*
 * Created by SharpDevelop.
 * User: Carlos
 * Date: 22/5/2021
 * Time: 12:25
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Clase05Gestion
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Label3Click(object sender, EventArgs e)
		{
	
		}
		void BtnLimpiarClick(object sender, EventArgs e)
		{
			//evento btnLimpiar
			txtPassword.Text="";
			txtUsername.Text="";
			lblInfo.Text="";
		}
		void BtnLoginClick(object sender, EventArgs e)
		{
			//evento btnLogin
			string[] usuarios = { "Juan", "Jose", "Maria", "Ana" };
            string[] claves = { "123", "111", "abc", "321" };
            
            string usuario = txtUsername.Text;
            string clave = txtPassword.Text;
            
            bool existe = false;
            int donde = 0;

            for(int a = 0; a < usuarios.Length; a++)
            {
                if (usuario == usuarios[a])
                {
                    existe = true;
                    donde = a;
                }
            }
            // Console.WriteLine(existe + " " + donde);
            if (existe && clave == claves[donde])   lblInfo.Text="Bienvenido "+usuario;
            if (existe && clave != claves[donde])   lblInfo.Text="Clave Incorrecta!";
            if (!existe)                            lblInfo.Text="Usuario Inexistente!";
		}
	}
}
